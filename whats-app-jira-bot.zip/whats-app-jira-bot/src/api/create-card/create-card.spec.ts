import { Test, TestingModule } from '@nestjs/testing';
import { CreateCard } from './create-card';

describe('CreateCard', () => {
  let provider: CreateCard;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CreateCard],
    }).compile();

    provider = module.get<CreateCard>(CreateCard);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });
});
