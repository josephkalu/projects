import { Body, Controller, Post, Get } from '@nestjs/common';
import { CreateIssueDto } from 'src/response/whatsApp.dto';
import { JiraService } from 'src/services/jira-service.service';

@Controller('create-card')
export class CreateCardController {
  constructor(private readonly jiraService: JiraService) {}

  @Post('whatsapp')
  async handleWhatsAppMessage(@Body() payload: CreateIssueDto) {

    const description = `${payload?.issue} \n Phone: ${payload?.phone} \n Image URL: ${payload?.imageUrl} \n Email: ${payload?.email} \n Location ${payload?.location}`
    const ticket = await this.jiraService.createTicket(
      payload.issue,
      description,
      payload.issueType,
    );

    if(ticket.key){
        return `Ticket created with ID: ${ticket.key}`;
    }
    return ticket;
    
  }

  @Get('fetch-user')
  async fetchUsers() {
    const users = await this.jiraService.fetchUsersAssignableToTask();

    console.log('Ticket', users);
    return {
      success: true,
      message: 'Assignable users fetched successfully',
      data: users,
    };
  }

  @Get('fetch-issue')
  async fetchIssue() {
    const users = await this.jiraService.fetchIssueType()

    console.log('Ticket', users);
    return {
      success: true,
      message: 'Assignable users fetched successfully',
      data: users,
    };
  }
}
