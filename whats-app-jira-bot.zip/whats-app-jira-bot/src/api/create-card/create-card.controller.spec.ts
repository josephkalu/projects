import { Test, TestingModule } from '@nestjs/testing';
import { CreateCardController } from './create-card.controller';

describe('CreateCardController', () => {
  let controller: CreateCardController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CreateCardController],
    }).compile();

    controller = module.get<CreateCardController>(CreateCardController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
