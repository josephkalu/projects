import { Module } from '@nestjs/common';
import { CreateCard } from './create-card';
import { JiraService } from 'src/services/jira-service.service';
import { CreateCardController } from './create-card.controller';

@Module({

  controllers: [CreateCardController,],
  providers: [CreateCard, JiraService,]
})
export class CreateCardModule {}
