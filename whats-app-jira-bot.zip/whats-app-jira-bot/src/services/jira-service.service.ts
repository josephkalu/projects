import { Injectable } from '@nestjs/common';
import axios from 'axios';

@Injectable()
export class JiraService {
  private APITOKEN =
    'ATATT3xFfGF0pwXV-nRatgl7hUz3lwB-VO5ApHBKsaR6X9Bxvh-Wa-Pl7ae1FPsoL2XKqSKaL46Arou8fb4MLEMKTMpchydJCyc_6Zs_uxAgZwzSwYk4YErlL3lkeha5n-162rmkWEHNv5Pr3CC3xJfYqWL23c1ZJq9AUcW5iPLJS8EA-dy73Pc=ABB47397';
  private jiraBaseUrl = 'https://complaintandissues.atlassian.net';
  private authHeader = {
    Authorization: `Basic ${Buffer.from(
      `thejosephkalu@gmail.com:${this.APITOKEN}`,
    ).toString('base64')}`,
  };
  private endpoint = `${this.jiraBaseUrl}/rest/api/2/issue`;
  private projectKey = 'TAL';

  async createTicket(
    summary: string,
    description: string,
    issueType: string,
  ): Promise<any> {
    const getIssueType = await this.fetchIssueType();
    const accountId = await this.fetchUsersAssignableToTask();

    console.log("Account", accountId)
    if (getIssueType) {
      if (!getIssueType.includes(issueType)) {
        console.log("In issue type")
        return 'Incorrect issue type';
      }
    }

    const data = {
      fields: {
        project: {
          key: this.projectKey,
        },
        summary,
        description,
        issuetype: {
          name: issueType,
        },
        assignee: {
            id: accountId
        },

      },
    };

    try {
      const response = await axios.post(this.endpoint, data, {
        headers: {
          ...this.authHeader,
          'Content-Type': 'application/json',
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error creating Jira ticket:', error.response?.data);
      throw new Error('Failed to create Jira ticket');
    }
  }

  async fetchUsersAssignableToTask(): Promise<string | null> {
    try {
      const response = await axios.get(
        `${this.jiraBaseUrl}/rest/api/2/user/assignable/search`,
        {
          headers: {
            ...this.authHeader,
            'Content-Type': 'application/json',
          },
          params: {
            project: this.projectKey,
          },
        },
      );

      const users = response.data || [];
      const activeUsers = users.filter((user) => user.active);

      if (activeUsers.length === 0) {
        console.warn('No active users found.');
        return null;
      }

      const randomIndex = Math.floor(Math.random() * activeUsers.length);
      const randomActiveUser = activeUsers[randomIndex];

      console.log('Random Active User Account ID:', randomActiveUser.accountId);
      return randomActiveUser.accountId;
    } catch (error) {
      console.error(
        'Error fetching assignable users:',
        error.response?.data || error.message,
      );
      throw new Error('Failed to fetch assignable users');
    }
  }

  async fetchUsersAssignableToTask2(): Promise<string | null> {
    try {
      const response = await axios.get(
        `${this.jiraBaseUrl}/rest/api/2/user/assignable/search`,
        {
          headers: {
            ...this.authHeader,
            'Content-Type': 'application/json',
          },
          params: {
            project: this.projectKey,
          },
        },
      );

      const users = response.data || [];
      const activeUsers = users.filter((user) => user.active);

      if (activeUsers.length === 0) {
        console.warn('No active users found.');
        return null;
      }

      const randomIndex = Math.floor(Math.random() * activeUsers.length);
      const randomActiveUser = activeUsers[randomIndex];

      console.log('Random Active User Account ID:', randomActiveUser.accountId);
      return randomActiveUser.accountId;
    } catch (error) {
      console.error(
        'Error fetching assignable users:',
        error.response?.data || error.message,
      );
      throw new Error('Failed to fetch assignable users');
    }
  }

  async fetchIssueType(): Promise<string[]> {
    try {
      const response = await axios.get(
        `${this.jiraBaseUrl}/rest/api/2/issue/createmeta`,
        {
          headers: {
            ...this.authHeader,
            'Content-Type': 'application/json',
          },
          params: {
            projectKeys: this.projectKey,
            expand: 'projects.issuetypes',
          },
        },
      );
      const project = response.data.projects.find(
        (project) => project.key === this.projectKey,
      );

      if (!project) {
        throw new Error(
          `Project with key '${this.projectKey}' not found in the response.`,
        );
      }

      const issueTypes = project.issuetypes || [];
      const issueTypeNames = issueTypes.map((issueType) => issueType.name);

      console.log('Issue Type Names:', issueTypeNames);
      return issueTypeNames;
    } catch (error) {
      console.error(
        'Error fetching issue type names:',
        error.response?.data || error.message,
      );
      throw new Error('Failed to fetch issue type names');
    }
  }
  a;
}
