import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CreateCard } from './api/create-card/create-card';
import { CreateCardController } from './api/create-card/create-card.controller';
import { CreateCardModule } from './api/create-card/create-card.module';

@Module({
  imports: [CreateCardModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
